# Top 100+ Essential English Fonts for Video Editors & Motion Designers

ဤ Folder (**what is motion**) ထဲတွင် ကမ္ဘာတစ်ဝှမ်းရှိ Video Editor များ၊ Motion Graphic Designer များနှင့် Content Creator များ (Premiere Pro, After Effects, DaVinci Resolve, CapCut, Final Cut Pro) အသုံးအများဆုံး **English Fonts ၁၀၈ မျိုး (TTF Format)** ကို အမျိုးအစားအလိုက် စနစ်တကျ စုစည်းထည့်သွင်းပေးထားပါသည်။

---

## ၁။ YouTube, TikTok & Reels Subtitles / Captions (Alex Hormozi & MrBeast Style)
စာတန်းထိုး (Captions) များနှင့် Thumbnails များတွင် ရုပ်ထွက်ပြတ်သားပြီး မျက်စိဆွဲဆောင်မှု အကောင်းဆုံး Bold & Impact ဖောင့်များ -

1. **Anton** - *Reels & Shorts Subtitles တွင် ကမ္ဘာ့အသုံးအများဆုံး နံပါတ် ၁ ဖောင့်*
2. **Bebas Neue** - *Classic YouTube Title & Subtitle ဖောင့်*
3. **Montserrat** - *သန့်ရှင်းပြီး ခေတ်ဆန်သော စာတန်းထိုးဖောင့် (Black / ExtraBold အသုံးများ)*
4. **Poppins** - *TikTok & CapCut Trend အဖြစ်ဆုံး Round Sans-Serif*
5. **Archivo Black** - *ထူထဲပြီး အဝေးကပင် ထင်းနေသော Title ဖောင့်*
6. **Oswald** - *ဒေါင်လိုက် ခေတ်ဆန်သော Heading ဖောင့်*
7. **League Spartan** - *MrBeast Style Punchy Title ဖောင့်*
8. **Russo One** - *Gaming & Action Subtitle ဖောင့်*
9. **Bangers** - *Comic & Gaming Funny Moments ဖောင့်*
10. **Luckiest Guy** - *MrBeast Thumbnail & CapCut Pop-up Subtitle*
11. **Lilita One** - *ကာတွန်းဆန်ဆန် ချစ်စရာ ပေါ့ပါးသော Subtitle*
12. **Titan One** - *Bubble-style ထူထူဖောင်းဖောင်းဖောင့်*
13. **Fredoka** - *Friendly & Modern Animated Subtitle*
14. **Rowdies** - *High-energy Dynamic Display*
15. **Black Han Sans** - *စူပါထူသော Block Subtitle*
16. **Bungee** - *Retro Pop-art Display*
17. **Alfa Slab One** - *Western / Heavy Slab Serif*
18. **Squada One** - *Condensed Tech Subtitle*
19. **Passion One** - *Compact Punchy Title*
20. **Paytone One** - *Casual Headline*
21. **Changa One** - *Geometric Impact*
22. **Sigmar** - *Fun / Playful Gaming Text*
23. **Bowlby One** - *Ultra Heavy Block Headline*
24. **Righteous** - *Retro Futuristic Subtitle*
25. **Days One** - *Modern Russian/Futuristic Block*
26. **Shrikhand** - *Curved Retro Display*
27. **Faster One** - *Speed / Racing Motion Text*
28. **Rammetto One** - *Bold High Contrast Headline*

---

## ၂။ Modern Motion Graphics & Clean Sans-Serif (Apple, Vox & Documentary Style)
Motion Graphics၊ Corporate Explainer နှင့် Tech Video များအတွက် သန့်ရှင်းတိကျသော စတိုင် -

29. **Inter** - *Apple & Figma Standard Clean Motion Graphic Font*
30. **Roboto** - *Universal Clean Subtitle & UI*
31. **Plus Jakarta Sans** - *ခေတ်သစ် Modern Tech Branding ဖောင့်*
32. **Outfit** - *Minimalist Geometric Sans*
33. **Urbanist** - *Sleek & Aesthetic Lifestyle Video Font*
34. **Sora** - *Japanese-inspired Futuristic Clean Font*
35. **Manrope** - *Professional Corporate Motion Graphic*
36. **DM Sans** - *Ultra Legible Documentary Subtitle*
37. **Space Grotesk** - *Tech / Web3 / Creative Agency Motion Font*
38. **Work Sans** - *Editorial Clean Sans*
39. **Epilogue** - *Variable Sans with Personality*
40. **Red Hat Display** - *Corporate Tech Brand Style*
41. **Public Sans** - *Government / Informative Documentary*
42. **Syne** - *Brutalist & High-Fashion Motion Graphic Trend*
43. **Unbounded** - *Modern Wide / Expanded Trendy Motion Font*
44. **Lexend** - *ဖတ်ရှုရ အလွန်လွယ်ကူသော Subtitle Font*
45. **Cabin** - *Humanist Sans-Serif*
46. **Raleway** - *Elegant Thin & Bold Display*
47. **Kanit** - *Modern Round Tech Sans*
48. **Rubik** - *Soft Rounded Modern Text*
49. **Chivo** - *High Performance Grotesque*
50. **Nunito** - *Friendly Rounded Motion Font*
51. **Quicksand** - *Aesthetic Clean Rounded*
52. **Jost** - *Futura-inspired Geometric Sans*
53. **Albert Sans** - *Modern Scandinavian Design*
54. **Figtree** - *Playful yet Crisp UI Motion*
55. **Archivo** - *Industrial Modern Sans*
56. **Geologica** - *Precision Engineering Style*
57. **Onest** - *Balanced High Legibility*
58. **Hanken Grotesk** - *Timeless British Grotesque*

---

## ၃။ Condensed & Vertical Titles (Movie Posters, Lower Thirds & Trailers)
အလျားလိုက်နေရာချွေတာပြီး အပေါ်အောက် ရှည်မျောကာ ထင်ရှားသော ရုပ်ရှင်စတိုင်ခေါင်းစဉ်ဖောင့်များ -

59. **Barlow Condensed** - *Cinematic Lower Thirds & Documentary Title*
60. **Saira Condensed** - *High-density Sports / Broadcast Text*
61. **Saira Extra Condensed** - *Ultra Narrow Movie Poster Style*
62. **Antonio** - *Modern Condensed Sans*
63. **Fjalla One** - *YouTube Banner & Lower Third Standard*
64. **Pathway Extreme** - *Ultra Condensed Modern Display*
65. **Six Caps** - *Tall & Narrow Poster Heading*
66. **Staatliches** - *Retro German Art-Deco Headline*
67. **Yanone Kaffeesatz** - *Classic Slender Display*
68. **Teko** - *Action / Sports Broadcast Title*
69. **Francois One** - *Billboard Style Condensed Headline*
70. **Big Shoulders Display** - *Chicago Protest / Urban Poster Art*
71. **Big Shoulders Inline Display** - *Layered Artistic Heading*
72. **Bai Jamjuree** - *Square-cut Condensed Display*
73. **BenchNine** - *Slender Vintage Headline*

---

## ၄။ Cinematic, Luxury & Documentary Serif (A24, Netflix & Luxury Brand Aesthetic)
ရုပ်ရှင်၊ မှတ်တမ်းတင်ဗီဒီယို၊ Luxury Lifestyle နှင့် မဂ္ဂဇင်းဆန်သော အထက်တန်းစား ဖောင့်များ -

74. **Cinzel** - *Roman Classical Cinematic Title (Netflix / Epic Trailers)*
75. **Cinzel Decorative** - *Fantasy / Mythological Epic Title*
76. **Playfair Display** - *High-end Luxury & Fashion Video Font*
77. **Cormorant Garamond** - *Timeless Fine Art / Vintage Luxury*
78. **DM Serif Display** - *Editorial / Drama Video Title*
79. **Bodoni Moda** - *Vogue / Fashion Magazine Headline*
80. **Prata** - *Tender & Elegant Serif*
81. **Marcellus** - *Ancient Roman Aesthetic*
82. **Forum** - *Classic Antique Architecture Style*
83. **Italiana** - *Italian High-Fashion Minimalist Serif*
84. **Castoro** - *Scholarly Documentary Narration*
85. **Yeseva One** - *Graceful Feminine Display*
86. **Rozha One** - *Dramatic High-Contrast Serif*
87. **Abril Fatface** - *Classic 19th Century Poster Font*
88. **Bellefair** - *Subtle & Slender High-end Title*

---

## ၅။ Cyberpunk, Sci-Fi, Tech & Gaming (HUD, Tech Review & Future Concept)
နည်းပညာသုံးသပ်ချက်များ၊ Cyberpunk နှင့် Gaming အထူးပြု စတိုင်ဖောင့်များ -

89. **Orbitron** - *Futuristic Sci-Fi HUD & Space UI Standard*
90. **Audiowide** - *Techno / EDM Music Video Title*
91. **Bruno Ace** - *Modern Automotive / Aerospace Design*
92. **Michroma** - *Sleek Micro-tech Headline*
93. **Exo 2** - *Futuristic Tech Lower Thirds & Body*
94. **Chakra Petch** - *Mecha / Cybernetic Title*
95. **Rajdhani** - *Esports & Tactical HUD Display*
96. **Space Mono** - *Coder / Hacker Terminal Text*
97. **Oxanium** - *Cyberpunk / Robotic Video Title*
98. **Share Tech Mono** - *Military / Radar Screen Telemetry*

---

## ၆။ Handwritten, Travel Vlog & Marker (Casual, Organic & Personal Brand)
Daily Vlogs၊ ခရီးသွားဗီဒီယိုများနှင့် အမှတ်တရဗီဒီယိုများတွင် အသုံးပြုသော သဘာဝလက်ရေးဖောင့်များ -

99. **Permanent Marker** - *Street Style / Bold Vlog Marker Text*
100. **Caveat** - *ချောမွေ့သဘာဝကျသော လက်ရေးမှတ်စုဖောင့်*
101. **Kalam** - *ဘောပင်လက်ရေးစစ်စစ် စတိုင်*
102. **Satisfy** - *Smooth Brush Script*
103. **Pacifico** - *California Surf / Summer Vacation Title*
104. **Yellowtail** - *Retro 1930s Sign Painter Script*
105. **Gloria Hallelujah** - *Playful Student Chalkboard Style*
106. **Rock Salt** - *Edgy Felt-tip Grunge Marker*
107. **Gochi Hand** - *Casual Teenage Diary Handwriting*
108. **Sedgwick Ave** - *Hip-Hop Graffiti Street Art Script*
